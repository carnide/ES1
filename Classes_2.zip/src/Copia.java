public class Copia {
    private int id;
    private Livro livro;

    public Copia(int id, Livro livro) {
        this.id = id;
        this.livro = livro;
    }

    public int getId() {
        return id;
    }

    public Livro getLivro() {
        return livro;
    }
}
